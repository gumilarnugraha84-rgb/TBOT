// cmd/myaccount.js - v5.0 — parallel queries, no loading msg, N+1 pagination
'use strict';

const db = require('../data/db');

const PAGE_SIZE = 5;

const LABEL = {
  SSH: '⚪ SSH', VMESS: '🔵 VMess', VLESS: '🟡 VLess',
  TROJAN: '🟠 Trojan', ZIVPN: '🟢 ZivPN'
};

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) =>
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null))
  );
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) =>
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []))
  );
}

function formatRow(r) {
  const now     = new Date();
  const exp     = new Date(r.expired_at);
  const sisa    = exp > now ? Math.ceil((exp - now) / 86400000) : 0;
  const isTrial = (r.product_type || '').includes('TRIAL');
  const statusIco = isTrial
    ? (sisa > 0 ? `🟡 ${sisa}hr TRIAL` : '❌ Expired')
    : (sisa > 3 ? `🟢 ${sisa}hr` : sisa > 0 ? `🟡 ${sisa}hr` : '🔴 Expired');
  const baseType = (r.product_type || '')
    .replace('RENEW ', '').replace('TRIAL-', '').replace('TRIAL ', '');
  const label = LABEL[baseType] || baseType || '?';
  return `│  ${label}: <b>${r.username || '-'}</b>\n│  📅 ${(r.expired_at || '').slice(0, 10) || '-'}  ${statusIco}\n│\n`;
}

module.exports = async function myaccountCmd(bot, chatId, msgId, page = 0) {
  try {
    const safePage = Math.max(0, page);

    /* ── Jalankan semua query paralel sekaligus ── */
    const [userRow, rows] = await Promise.all([
      dbGet('SELECT saldo, role, created_at FROM users WHERE chat_id=?', [chatId]),
      dbAll(
        "SELECT product_type, username, expired_at FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('', 'TOPUP') ORDER BY expired_at DESC LIMIT ? OFFSET ?",
        [chatId, PAGE_SIZE + 1, safePage * PAGE_SIZE]
      )
    ]);

    if (!userRow) {
      return bot.editMessageText('❌ User tidak ditemukan. Ketik /start', {
        chat_id: chatId, message_id: msgId,
        reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
      }).catch(() => {});
    }

    /* ── N+1 trick: cek ada halaman berikutnya ── */
    const hasNext  = rows.length > PAGE_SIZE;
    const pageRows = hasNext ? rows.slice(0, PAGE_SIZE) : rows;
    const hasPrev  = safePage > 0;

    /* Edge case: halaman kosong karena data berubah → mundur ke halaman sebelumnya */
    if (pageRows.length === 0 && safePage > 0) {
      return myaccountCmd(bot, chatId, msgId, safePage - 1);
    }

    const saldo    = Number(userRow.saldo) || 0;
    const role     = userRow.role || 'members';
    const joinDate = userRow.created_at ? userRow.created_at.slice(0, 10) : '-';

    let akunText = '';
    if (!pageRows.length) {
      akunText = '│  📭 Belum ada akun aktif\n';
    } else {
      pageRows.forEach(r => { akunText += formatRow(r); });
    }

    const pageLabel = (hasPrev || hasNext)
      ? `Halaman ${safePage + 1}${hasNext ? '' : ' (terakhir)'}`
      : `${pageRows.length} akun`;

    const text =
`┌─────────────────┐
│  👤 MY ACCOUNT
└─────────────────┘
│  🆔 Chat ID  : <code>${chatId}</code>
│  👑 Role     : <b>${role.toUpperCase()}</b>
│  💰 Saldo    : <b>Rp ${saldo.toLocaleString('id-ID')}</b>
│  📅 Join     : ${joinDate}
├─────────────────┤
│  📦 AKUN (${pageLabel})
├─────────────────┤
${akunText}└─────────────────┘`;

    /* ── Tombol navigasi ── */
    const navRow = [];
    if (hasPrev) navRow.push({ text: '◀️ Sebelumnya', callback_data: `myacc_p_${safePage - 1}` });
    if (hasNext) navRow.push({ text: '▶️ Berikutnya', callback_data: `myacc_p_${safePage + 1}` });

    const keyboard = [];
    if (navRow.length) keyboard.push(navRow);
    keyboard.push([
      { text: '🔄 Extend Akun',    callback_data: 'renew_menu'   },
      { text: '📜 Riwayat',        callback_data: 'menu_history' }
    ]);
    keyboard.push([{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]);

    await bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (err) {
    console.error('[myaccount]', err.message);
    bot.editMessageText('❌ Gagal memuat data. Coba lagi.', {
      chat_id: chatId, message_id: msgId,
      reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
    }).catch(() => {});
  }
};
