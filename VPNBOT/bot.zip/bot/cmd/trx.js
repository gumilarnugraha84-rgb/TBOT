// cmd/trx.js - Riwayat Transaksi (Optimized v2.0)
'use strict';

const db = require('../data/db');

module.exports = function trxCmd(bot, chatId, msgId) {
  bot.editMessageText('⏳ <i>Memuat riwayat transaksi...</i>', {
    chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
  }).catch(() => {});

  db.all(
    "SELECT product_type, amount, status, created_at, username FROM transactions WHERE chat_id=? ORDER BY created_at DESC LIMIT 10",
    [chatId],
    (err, rows) => {
      if (err) {
        console.error('[trxCmd] ❌', err.message);
        return bot.editMessageText('❌ Gagal load riwayat.', {
          chat_id: chatId, message_id: msgId,
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
        }).catch(() => {});
      }

      let text = `┌─────────────────┐\n│  📜 RIWAYAT TRANSAKSI\n└─────────────────┘\n\n`;

      if (!rows?.length) {
        text += '📭 Belum ada transaksi.';
      } else {
        rows.forEach((r, i) => {
          const status = r.status === 'completed' ? '✅' : r.status === 'pending' ? '⏳' : '❌';
          const date   = r.created_at ? r.created_at.slice(0, 16) : '-';
          const user   = r.username ? ` • ${r.username}` : '';
          text += `${i + 1}. ${status} <b>${r.product_type || '-'}</b>${user}\n`;
          text += `   💰 Rp ${Number(r.amount).toLocaleString('id-ID')}  📅 ${date}\n\n`;
        });
      }

      bot.editMessageText(text, {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
      }).catch(() => {});
    }
  );
};
