module.exports = {
  members: {
    ssh:      { perDay: 300 },
    vmess:    { perDay: 300 },
    vless:    { perDay: 300 },
    trojan:   { perDay: 300 },
    udpzivpn: { perDay: 300 }
  },
  reseller: {
    ssh:      { perDay: 200 },
    vmess:    { perDay: 200 },
    vless:    { perDay: 200 },
    trojan:   { perDay: 200 },
    udpzivpn: { perDay: 200 }
  }
};
